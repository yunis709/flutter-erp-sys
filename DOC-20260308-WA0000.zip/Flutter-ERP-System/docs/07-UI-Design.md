# 🎨 تصميم الواجهات

## 🎯 مقدمة

يقدم هذا المستند تصميم الواجهات لجميع شاشات النظام مع الألوان، المكونات، والتخطيطات.

---

## 🎨 نظام الألوان

### اللون الأساسي

```dart
// lib/core/theme/colors.dart
import 'package:flutter/material.dart';

class AppColors {
  // Primary
  static const Color primary = Color(0xFF0F172A);
  static const Color primaryLight = Color(0xFF1E293B);
  static const Color primaryDark = Color(0xFF020617);
  
  // Secondary
  static const Color secondary = Color(0xFF3B82F6);
  static const Color secondaryLight = Color(0xFF60A5FA);
  static const Color secondaryDark = Color(0xFF2563EB);
  
  // Accent
  static const Color accent = Color(0xFF10B981);
  static const Color warning = Color(0xFFF59E0B);
  static const Color error = Color(0xFFEF4444);
  static const Color info = Color(0xFF3B82F6);
  
  // Background
  static const Color background = Color(0xFFF8FAFC);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color card = Color(0xFFFFFFFF);
  
  // Text
  static const Color textPrimary = Color(0xFF0F172A);
  static const Color textSecondary = Color(0xFF64748B);
  static const Color textMuted = Color(0xFF94A3B8);
  
  // Border
  static const Color border = Color(0xFFE2E8F0);
  static const Color divider = Color(0xFFE2E8F0);
}
```

### الثيم

```dart
// lib/core/theme/app_theme.dart
import 'package:flutter/material.dart';
import 'colors.dart';

class AppTheme {
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: const ColorScheme.light(
        primary: AppColors.primary,
        secondary: AppColors.secondary,
        surface: AppColors.surface,
        background: AppColors.background,
        error: AppColors.error,
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onSurface: AppColors.textPrimary,
        onBackground: AppColors.textPrimary,
      ),
      scaffoldBackgroundColor: AppColors.background,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardTheme(
        color: AppColors.card,
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.secondary),
        ),
      ),
    );
  }
}
```

---

## 🖥️ شاشة نقاط البيع (POS)

### التخطيط

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  [الشعار]  سوبر ماركت الأمل    │    14:32    │    [👤 أحمد] [⚙️] [🚪]    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────┐  ┌─────────────────────────────┐  │
│  │  🔍 البحث...                        │  │        سلة المشتريات        │  │
│  │                                     │  │  ─────────────────────────  │  │
│  │  ┌────────┐┌────────┐┌────────┐    │  │  تفاح أحمر    2×5.50  11.00│  │
│  │  │ 🍎     ││ 🥛     ││ 🍞     │    │  │  حليب كامل    1×8.00   8.00│  │
│  │  │تفاح   ││حليب   ││خبز    │    │  │  خبز فرنسي    3×5.00  15.00│  │
│  │  │5.50   ││8.00   ││5.00   │    │  │  ─────────────────────────  │  │
│  │  └────────┘└────────┘└────────┘    │  │  المجموع:            34.00 │  │
│  │                                     │  │  الضريبة (15%):       5.10 │  │
│  │  ┌────────┐┌────────┐┌────────┐    │  │  ═════════════════════════  │  │
│  │  │ 🧀     ││ 🍫     ││ 🥤     │    │  │  الإجمالي:           39.10 │  │
│  │  │جبن    ││شوكولاتة││عصير   │    │  │                             │  │
│  │  │15.00  ││12.00  ││6.00   │    │  │  [🎁 خصم] [🗑️ إفراغ]       │  │
│  │  └────────┘└────────┘└────────┘    │  │                             │  │
│  │                                     │  │  ┌─────────────────────┐   │  │
│  │  [فواكه] [ألبان] [مخبوزات] [كل]   │  │  │   💰 إتمام الدفع    │   │  │
│  │                                     │  │  │      39.10 ريال     │   │  │
│  └─────────────────────────────────────┘  │  └─────────────────────┘   │  │
│                                           └─────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

### الكود

```dart
// lib/screens/pos/pos_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/cart_provider.dart';
import 'cart_widget.dart';
import 'product_grid.dart';
import 'payment_dialog.dart';

class POSScreen extends ConsumerWidget {
  const POSScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cart = ref.watch(cartProvider);
    final cartNotifier = ref.read(cartProvider.notifier);

    return Scaffold(
      appBar: AppBar(
        title: const Text('نقطة البيع'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => context.push('/settings'),
          ),
        ],
      ),
      body: Row(
        children: [
          // المنتجات
          Expanded(
            flex: 2,
            child: Column(
              children: [
                // شريط البحث
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: TextField(
                    autofocus: true,
                    decoration: InputDecoration(
                      hintText: 'امسح الباركود أو اكتب اسم المنتج...',
                      prefixIcon: const Icon(Icons.qr_code_scanner),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.search),
                        onPressed: () {},
                      ),
                    ),
                    onSubmitted: (value) => _searchProduct(context, value),
                  ),
                ),
                // شبكة المنتجات
                const Expanded(
                  child: ProductGrid(),
                ),
                // الفئات
                Container(
                  height: 50,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _CategoryChip(label: 'الكل', isSelected: true),
                      _CategoryChip(label: 'فواكه'),
                      _CategoryChip(label: 'ألبان'),
                      _CategoryChip(label: 'مخبوزات'),
                      _CategoryChip(label: 'مشروبات'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // السلة
          const CartWidget(),
        ],
      ),
    );
  }

  void _searchProduct(BuildContext context, String query) {
    // البحث عن المنتج وإضافته للسلة
  }
}

class _CategoryChip extends StatelessWidget {
  final String label;
  final bool isSelected;

  const _CategoryChip({
    required this.label,
    this.isSelected = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: FilterChip(
        label: Text(label),
        selected: isSelected,
        onSelected: (value) {},
      ),
    );
  }
}
```

---

## 🛒 ويدجت السلة

```dart
// lib/screens/pos/cart_widget.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/colors.dart';
import '../../providers/cart_provider.dart';
import 'payment_dialog.dart';

class CartWidget extends ConsumerWidget {
  const CartWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cart = ref.watch(cartProvider);
    final cartNotifier = ref.read(cartProvider.notifier);

    final subtotal = cartNotifier.subtotal;
    final tax = cartNotifier.tax;
    final total = cartNotifier.total;

    return Container(
      width: 400,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
          left: BorderSide(color: Colors.grey.shade300),
        ),
      ),
      child: Column(
        children: [
          // عنوان السلة
          Container(
            padding: const EdgeInsets.all(16),
            color: AppColors.primary,
            child: Row(
              children: [
                const Icon(Icons.shopping_cart, color: Colors.white),
                const SizedBox(width: 8),
                const Text(
                  'سلة المشتريات',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Text(
                  '${cart.length} عنصر',
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
          // عناصر السلة
          Expanded(
            child: cart.isEmpty
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.shopping_basket_outlined, size: 64, color: Colors.grey),
                        SizedBox(height: 16),
                        Text('السلة فارغة', style: TextStyle(color: Colors.grey)),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: cart.length,
                    itemBuilder: (context, index) {
                      final item = cart[index];
                      return ListTile(
                        title: Text(item.product.name),
                        subtitle: Text('${item.product.salePrice.toStringAsFixed(2)} ريال'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.remove_circle_outline),
                              onPressed: () => cartNotifier.updateQuantity(
                                item.product.id!,
                                item.quantity - 1,
                              ),
                            ),
                            Text('${item.quantity.toInt()}'),
                            IconButton(
                              icon: const Icon(Icons.add_circle_outline),
                              onPressed: () => cartNotifier.updateQuantity(
                                item.product.id!,
                                item.quantity + 1,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              '${(item.product.salePrice * item.quantity).toStringAsFixed(2)}',
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
          // الإجمالي والدفع
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              border: Border(
                top: BorderSide(color: Colors.grey.shade300),
              ),
            ),
            child: Column(
              children: [
                _buildTotalRow('المجموع:', subtotal),
                _buildTotalRow('الضريبة (15%):', tax),
                const Divider(height: 24),
                _buildTotalRow('الإجمالي:', total, isBold: true),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton.icon(
                    onPressed: cart.isEmpty
                        ? null
                        : () => showPaymentDialog(context, total),
                    icon: const Icon(Icons.payment),
                    label: Text(
                      'إتمام الدفع - ${total.toStringAsFixed(2)} ريال',
                      style: const TextStyle(fontSize: 18),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.accent,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTotalRow(String label, double amount, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: isBold ? 18 : 14,
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            '${amount.toStringAsFixed(2)} ريال',
            style: TextStyle(
              fontSize: isBold ? 20 : 14,
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
              color: isBold ? AppColors.primary : null,
            ),
          ),
        ],
      ),
    );
  }
}
```

---

## 📋 شاشة المخزون

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  [←] المخزون                    [🔍 البحث...]    [➕ إضافة منتج]          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  #  │ الباركود  │ اسم المنتج      │ السعر  │ المخزون │ حالة      │   │
│  ├─────┼───────────┼─────────────────┼────────┼─────────┼───────────┤   │
│  │  1  │ 123456789 │ تفاح أحمر       │ 5.50   │ 250     │ ✅ جيد    │   │
│  │  2  │ 987654321 │ حليب كامل       │ 8.00   │ 12      │ ⚠️ منخفض │   │
│  │  3  │ 456789123 │ خبز فرنسي       │ 5.00   │ 0       │ ❌ نافد   │   │
│  ├─────┼───────────┼─────────────────┼────────┼─────────┼───────────┤   │
│  │     │           │                 │        │         │           │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  الصفحة 1 من 5                    [<] [1] [2] [3] [4] [5] [>]              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 📊 شاشة التقارير

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  [←] التقارير                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  [مبيعات يومية] [مبيعات شهري] [المخزون] [العملاء] [المالية]              │
│                                                                             │
│  ┌─────────────────────────────────┐  ┌─────────────────────────────────┐  │
│  │      مبيعات هذا الأسبوع         │  │    توزيع المبيعات حسب الفئة    │  │
│  │                                 │  │                                 │  │
│  │    ▲                            │  │         ╭──────╮               │  │
│  │    │    ╱╲    ╱╲                │  │        ╱  35%  ╲              │  │
│  │    │   ╱  ╲  ╱  ╬               │  │       │  فواكه  │              │  │
│  │    │  ╱    ╲╱    ╲              │  │        ╲       ╱              │  │
│  │    │ ╱              ╲           │  │         ╰──────╯               │  │
│  │    └──────────────────          │  │      🥛 25%  🍞 20%            │  │
│  │      س م أ خ ج س                  │  │                                 │  │
│  │                                 │  │                                 │  │
│  └─────────────────────────────────┘  └─────────────────────────────────┘  │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  أفضل المنتجات مبيعاً                                              │   │
│  │  1. تفاح أحمر - 250 كجم - 1,375 ريال                              │   │
│  │  2. حليب طازج - 180 علبة - 1,440 ريال                             │   │
│  │  3. خبز فرنسي - 150 ربطة - 750 ريال                               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  [📄 تصدير PDF]  [📊 تصدير Excel]                                         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 📱 المكونات المشتركة

### بطاقة المنتج

```dart
// lib/widgets/pos/product_card.dart
import 'package:flutter/material.dart';
import '../../data/models/product_model.dart';

class ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback onTap;

  const ProductCard({
    super.key,
    required this.product,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // صورة المنتج
            Expanded(
              child: Container(
                color: Colors.grey.shade200,
                child: const Icon(Icons.image, size: 48, color: Colors.grey),
              ),
            ),
            // معلومات المنتج
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${product.salePrice.toStringAsFixed(2)} ريال',
                    style: TextStyle(
                      color: Theme.of(context).primaryColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  if (product.isLowStock)
                    Container(
                      margin: const EdgeInsets.only(top: 4),
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.orange.shade100,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        'مخزون منخفض',
                        style: TextStyle(
                          color: Colors.orange.shade800,
                          fontSize: 10,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
```

---

**الوثيقة:** تصميم الواجهات  
**الإصدار:** 1.0  
**تاريخ التحديث:** 2026-03-08
