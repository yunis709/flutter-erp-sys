# 🖨️ نظام الطباعة

## 🎯 مقدمة

يقدم هذا المستند نظام الطباعة للفواتير الحرارية مع دعم طابعات ESC/POS.

---

## 🏛️ البنية

```mermaid
flowchart TB
    subgraph App["Flutter App"]
        Invoice[Invoice Data]
        Formatter[ESC/POS Formatter]
    end
    
    subgraph Printer["طابعة حرارية"]
        Network[Network Printer]
        USB[USB Printer]
    end
    
    App -->|ESC/POS Commands| Printer
```

---

## 🔧 خدمة الطباعة

```dart
// lib/services/print_service.dart
import 'package:esc_pos_printer/esc_pos_printer.dart';
import 'package:esc_pos_utils/esc_pos_utils.dart';
import '../data/models/invoice_model.dart';

class PrintService {
  static const String defaultPrinterIp = '192.168.1.100';
  static const int defaultPrinterPort = 9100;

  /// طباعة فاتورة
  static Future<bool> printInvoice(Invoice invoice, {String? printerIp}) async {
    try {
      final profile = await CapabilityProfile.load();
      final printer = NetworkPrinter(PaperSize.mm80, profile);

      // الاتصال بالطابعة
      final result = await printer.connect(
        printerIp ?? defaultPrinterIp,
        port: defaultPrinterPort,
      );

      if (result != PosPrintResult.success) {
        print('فشل الاتصال بالطابعة: $result');
        return false;
      }

      // طباعة الفاتورة
      await _printHeader(printer);
      await _printInvoiceInfo(printer, invoice);
      await _printItems(printer, invoice.items);
      await _printTotals(printer, invoice);
      await _printFooter(printer);

      // قطع الورق
      printer.feed(3);
      printer.cut();
      printer.disconnect();

      return true;
    } catch (e) {
      print('خطأ في الطباعة: $e');
      return false;
    }
  }

  /// طباعة الهيدر
  static Future<void> _printHeader(NetworkPrinter printer) async {
    printer.setStyles(const PosStyles(
      align: PosAlign.center,
      bold: true,
      height: PosTextSize.size2,
      width: PosTextSize.size2,
    ));
    printer.text('سوبر ماركت الأمل');
    
    printer.setStyles(const PosStyles(
      align: PosAlign.center,
      bold: true,
    ));
    printer.text('فاتورة ضريبية مبسطة');
    printer.hr();
  }

  /// طباعة معلومات الفاتورة
  static Future<void> _printInvoiceInfo(
    NetworkPrinter printer,
    Invoice invoice,
  ) async {
    printer.setStyles(const PosStyles(align: PosAlign.left));
    printer.text('رقم الفاتورة: ${invoice.invoiceNumber}');
    printer.text('التاريخ: ${_formatDate(invoice.createdAt)}');
    printer.text('الكاشير: ${invoice.userName}');
    if (invoice.customerName != null) {
      printer.text('العميل: ${invoice.customerName}');
    }
    printer.hr();
  }

  /// طباعة العناصر
  static Future<void> _printItems(
    NetworkPrinter printer,
    List<InvoiceItem> items,
  ) async {
    // عنوان الأعمدة
    printer.row([
      PosColumn(text: 'المنتج', width: 6, styles: const PosStyles(bold: true)),
      PosColumn(text: 'الكمية', width: 2, styles: const PosStyles(bold: true)),
      PosColumn(
        text: 'السعر',
        width: 4,
        styles: const PosStyles(bold: true, align: PosAlign.right),
      ),
    ]);

    // عناصر الفاتورة
    for (final item in items) {
      printer.row([
        PosColumn(text: item.productName, width: 6),
        PosColumn(text: '${item.quantity.toInt()}', width: 2),
        PosColumn(
          text: '${item.total.toStringAsFixed(2)}',
          width: 4,
          styles: const PosStyles(align: PosAlign.right),
        ),
      ]);
    }

    printer.hr();
  }

  /// طباعة الإجماليات
  static Future<void> _printTotals(NetworkPrinter printer, Invoice invoice) async {
    // المجموع
    printer.row([
      PosColumn(text: 'المجموع:', width: 6),
      PosColumn(
        text: '${invoice.subtotal.toStringAsFixed(2)} ريال',
        width: 6,
        styles: const PosStyles(align: PosAlign.right),
      ),
    ]);

    // الخصم
    if (invoice.discount > 0) {
      printer.row([
        PosColumn(text: 'الخصم:', width: 6),
        PosColumn(
          text: '${invoice.discount.toStringAsFixed(2)} ريال',
          width: 6,
          styles: const PosStyles(align: PosAlign.right),
        ),
      ]);
    }

    // الضريبة
    printer.row([
      PosColumn(text: 'الضريبة (15%):', width: 6),
      PosColumn(
        text: '${invoice.tax.toStringAsFixed(2)} ريال',
        width: 6,
        styles: const PosStyles(align: PosAlign.right),
      ),
    ]);

    // الإجمالي
    printer.setStyles(const PosStyles(bold: true, height: PosTextSize.size2));
    printer.row([
      PosColumn(text: 'الإجمالي:', width: 6),
      PosColumn(
        text: '${invoice.total.toStringAsFixed(2)} ريال',
        width: 6,
        styles: const PosStyles(
          align: PosAlign.right,
          bold: true,
          height: PosTextSize.size2,
        ),
      ),
    ]);

    // المدفوع والباقي
    if (invoice.paidAmount > 0) {
      printer.setStyles(const PosStyles());
      printer.row([
        PosColumn(text: 'المدفوع:', width: 6),
        PosColumn(
          text: '${invoice.paidAmount.toStringAsFixed(2)} ريال',
          width: 6,
          styles: const PosStyles(align: PosAlign.right),
        ),
      ]);

      final change = invoice.paidAmount - invoice.total;
      if (change > 0) {
        printer.row([
          PosColumn(text: 'الباقي:', width: 6),
          PosColumn(
            text: '${change.toStringAsFixed(2)} ريال',
            width: 6,
            styles: const PosStyles(align: PosAlign.right),
          ),
        ]);
      }
    }

    printer.hr();
  }

  /// طباعة الفوتر
  static Future<void> _printFooter(NetworkPrinter printer) async {
    printer.setStyles(const PosStyles(align: PosAlign.center));
    printer.text('شكراً لتسوقكم معنا!');
    printer.text('الرقم الضريبي: 300123456700003');
    printer.text('للاستفسار: 050-1234567');
    printer.feed(2);
  }

  /// تنسيق التاريخ
  static String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/'
        '${date.month.toString().padLeft(2, '0')}/'
        '${date.year} '
        '${date.hour.toString().padLeft(2, '0')}:''
        '${date.minute.toString().padLeft(2, '0')}';
  }

  /// اختبار الاتصال بالطابعة
  static Future<bool> testConnection(String ip, int port) async {
    try {
      final profile = await CapabilityProfile.load();
      final printer = NetworkPrinter(PaperSize.mm80, profile);
      final result = await printer.connect(ip, port: port);
      
      if (result == PosPrintResult.success) {
        printer.text('اختبار ناجح!');
        printer.feed(2);
        printer.cut();
        printer.disconnect();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }
}
```

---

## 📄 نموذج فاتورة مطبوعة

```
┌─────────────────────────────────────────────────┐
│                                                 │
│              سوبر ماركت الأمل                   │
│                                                 │
│           فاتورة ضريبية مبسطة                  │
│─────────────────────────────────────────────────│
│ رقم الفاتورة: INV-2026-0001                     │
│ التاريخ: 08/03/2026 14:32                       │
│ الكاشير: أحمد                                   │
│─────────────────────────────────────────────────│
│ المنتج              الكمية    السعر             │
│─────────────────────────────────────────────────│
│ تفاح أحمر           2         11.00             │
│ حليب كامل           1          8.00             │
│ خبز فرنسي           3         15.00             │
│─────────────────────────────────────────────────│
│ المجموع:                         34.00 ريال     │
│ الضريبة (15%):                    5.10 ريال     │
│─────────────────────────────────────────────────│
│ الإجمالي:                        39.10 ريال     │
│ المدفوع:                         50.00 ريال     │
│ الباقي:                          10.90 ريال     │
│─────────────────────────────────────────────────│
│                                                 │
│           شكراً لتسوقكم معنا!                  │
│        الرقم الضريبي: 300123456700003          │
│           للاستفسار: 050-1234567               │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## ⚙️ إعدادات الطابعة

```dart
// lib/screens/settings/printer_settings.dart
import 'package:flutter/material.dart';
import '../../services/print_service.dart';

class PrinterSettingsScreen extends StatefulWidget {
  const PrinterSettingsScreen({super.key});

  @override
  State<PrinterSettingsScreen> createState() => _PrinterSettingsScreenState();
}

class _PrinterSettingsScreenState extends State<PrinterSettingsScreen> {
  final _ipController = TextEditingController(text: '192.168.1.100');
  final _portController = TextEditingController(text: '9100');
  bool _isTesting = false;
  String? _testResult;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إعدادات الطابعة')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'عنوان الطابعة',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _ipController,
              decoration: const InputDecoration(
                hintText: '192.168.1.100',
                prefixIcon: Icon(Icons.print),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'المنفذ',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _portController,
              decoration: const InputDecoration(
                hintText: '9100',
                prefixIcon: Icon(Icons.settings_ethernet),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _isTesting ? null : _testPrinter,
                icon: _isTesting
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.print),
                label: Text(_isTesting ? 'جاري الاختبار...' : 'اختبار الطابعة'),
              ),
            ),
            if (_testResult != null) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _testResult!.contains('ناجح')
                      ? Colors.green.shade50
                      : Colors.red.shade50,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(
                      _testResult!.contains('ناجح') ? Icons.check_circle : Icons.error,
                      color: _testResult!.contains('ناجح') ? Colors.green : Colors.red,
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(_testResult!)),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _testPrinter() async {
    setState(() {
      _isTesting = true;
      _testResult = null;
    });

    final ip = _ipController.text;
    final port = int.tryParse(_portController.text) ?? 9100;

    final success = await PrintService.testConnection(ip, port);

    setState(() {
      _isTesting = false;
      _testResult = success
          ? '✅ اختبار ناجح! تم الاتصال بالطابعة.'
          : '❌ فشل الاتصال بالطابعة. تأكد من العنوان والمنفذ.';
    });
  }

  @override
  void dispose() {
    _ipController.dispose();
    _portController.dispose();
    super.dispose();
  }
}
```

---

## 🖨️ الطابعات المدعومة

| الطابعة | البروتوكول | الاختبار |
|---------|-----------|----------|
| EPSON TM-T88V | ESC/POS | ✅ |
| EPSON TM-T20 | ESC/POS | ✅ |
| Xprinter XP-80 | ESC/POS | ✅ |
| Bixolon SRP-350 | ESC/POS | ✅ |

---

**الوثيقة:** نظام الطباعة  
**الإصدار:** 1.0  
**تاريخ التحديث:** 2026-03-08
