# 📡 API التكامل

## 🎯 مقدمة

يقدم هذا المستند تكامل Supabase API للمزامنة والنسخ الاحتياطي.

---

## 🏛️ البنية

```mermaid
flowchart TB
    subgraph Flutter["Flutter App"]
        Client[Supabase Client]
    end
    
    subgraph Supabase["Supabase"]
        Auth[Authentication]
        REST[REST API]
        Realtime[Realtime]
        Storage[Storage]
    end
    
    subgraph Database["PostgreSQL"]
        Tables[Tables]
        RLS[Row Level Security]
    end
    
    Flutter -->|HTTP/WebSocket| Supabase
    Supabase --> Database
```

---

## 🔧 إعداد Supabase

### 1. إنشاء مشروع

```bash
# عبر موقع Supabase
# https://supabase.com/dashboard
```

### 2. إعدادات Flutter

```dart
// lib/main.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await Supabase.initialize(
    url: 'https://your-project.supabase.co',
    anonKey: 'your-anon-key',
  );
  
  runApp(const MyApp());
}

// دستر سريع
final supabase = Supabase.instance.client;
```

### 3. ملف .env

```bash
# .env
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
```

```yaml
# pubspec.yaml
dependencies:
  flutter_dotenv: ^5.1.0
  supabase_flutter: ^2.5.0
```

---

## 🔐 المصادقة

### تسجيل الدخول

```dart
// lib/services/auth_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  final SupabaseClient _client = Supabase.instance.client;

  /// تسجيل الدخول
  Future<AuthResponse> signIn(String email, String password) async {
    return await _client.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }

  /// تسجيل الخروج
  Future<void> signOut() async {
    await _client.auth.signOut();
  }

  /// الحصول على المستخدم الحالي
  User? get currentUser => _client.auth.currentUser;

  /// التحقق من حالة المصادقة
  bool get isAuthenticated => currentUser != null;

  /// استماع لتغييرات المصادقة
  Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;
}
```

---

## 📊 CRUD Operations

### قراءة البيانات

```dart
// قراءة جميع المنتجات
final products = await supabase
  .from('products')
  .select();

// قراءة منتج محدد
final product = await supabase
  .from('products')
  .select()
  .eq('id', 1)
  .single();

// بحث
final results = await supabase
  .from('products')
  .select()
  .ilike('name', '%تفاح%');

// تصفية وترتيب
final filtered = await supabase
  .from('products')
  .select()
  .gt('stock_quantity', 0)
  .order('name', ascending: true);
```

### إنشاء سجل

```dart
// إنشاء منتج
final newProduct = await supabase
  .from('products')
  .insert({
    'name': 'تفاح أحمر',
    'barcode': '123456789',
    'sale_price': 5.50,
    'cost_price': 3.00,
    'stock_quantity': 100,
  })
  .select()
  .single();
```

### تحديث سجل

```dart
// تحديث منتج
await supabase
  .from('products')
  .update({
    'sale_price': 6.00,
    'stock_quantity': 150,
  })
  .eq('id', 1);
```

### حذف سجل

```dart
// حذف منتج
await supabase
  .from('products')
  .delete()
  .eq('id', 1);
```

---

## 🔄 Realtime Subscriptions

```dart
// lib/services/realtime_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';

class RealtimeService {
  final SupabaseClient _client = Supabase.instance.client;

  /// استماع لتغييرات المنتجات
  void listenToProducts(Function callback) {
    _client
      .from('products')
      .stream(primaryKey: ['id'])
      .listen((data) {
        callback(data);
      });
  }

  /// استماع لفاتورة محددة
  void listenToInvoice(int invoiceId, Function callback) {
    _client
      .from('invoices')
      .stream(primaryKey: ['id'])
      .eq('id', invoiceId)
      .listen((data) {
        callback(data);
      });
  }
}
```

---

## 📁 Storage

### رفع ملف

```dart
// رفع صورة
final file = File('path/to/image.jpg');
final response = await supabase.storage
  .from('products')
  .upload('product_1.jpg', file);

// الحصول على الرابط
final url = supabase.storage
  .from('products')
  .getPublicUrl('product_1.jpg');
```

### تحميل ملف

```dart
// تحميل صورة
final response = await supabase.storage
  .from('products')
  .download('product_1.jpg');
```

---

## 🛡️ Row Level Security (RLS)

### سياسات الأمان

```sql
-- تفعيل RLS
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- السماح للمستخدمين المسجلين بالقراءة
CREATE POLICY "Allow read for authenticated users"
ON products FOR SELECT
TO authenticated
USING (true);

-- السماح للمستخدمين بتعديل بياناتهم فقط
CREATE POLICY "Allow update for own data"
ON products FOR UPDATE
TO authenticated
USING (auth.uid() = user_id);

-- السماح للمسؤولين بالكل
CREATE POLICY "Allow all for admins"
ON products FOR ALL
TO authenticated
USING (auth.jwt() ->> 'role' = 'admin');
```

---

## 📊 Edge Functions (اختياري)

```typescript
// supabase/functions/sync-invoices/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

serve(async (req) => {
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_ANON_KEY') ?? ''
  )

  const { invoices } = await req.json()

  // معالجة الفواتير
  const { data, error } = await supabase
    .from('invoices')
    .upsert(invoices)

  if (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
    })
  }

  return new Response(JSON.stringify({ success: true, data }), {
    headers: { 'Content-Type': 'application/json' },
  })
})
```

---

## 💰 التسعير

| الخطة | السعر | التخزين | الاتصالات | المناسب لـ |
|-------|-------|---------|-----------|------------|
| **Free** | $0 | 500 MB | 200K/شهر | محلات صغيرة |
| Pro | $25 | 8 GB | Unlimited | محلات متوسطة |
| Team | $599 | Unlimited | Unlimited | سلاسل محلات |

**للمحلات الصغيرة: Free Tier كافي تماماً**

---

**الوثيقة:** API التكامل  
**الإصدار:** 1.0  
**تاريخ التحديث:** 2026-03-08
