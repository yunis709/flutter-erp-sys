# 🔒 الأمان

## 🎯 مقدمة

يقدم هذا المستند استراتيجية الأمان للتطبيق مع حماية البيانات المحلية والمزامنة.

---

## 🏛️ هيكل الأمان

```mermaid
flowchart TB
    subgraph App["التطبيق"]
        Auth[المصادقة]
        Encrypt[تشفير البيانات]
        Backup[نسخ احتياطي]
    end
    
    subgraph Local["محلي"]
        SQLite[(SQLite)]
        Prefs[SharedPreferences]
    end
    
    subgraph Cloud["سحابة"]
        Supabase[Supabase Auth]
        RLS[Row Level Security]
    end
    
    App --> Local
    App -.-> Cloud
```

---

## 🔐 المصادقة المحلية

```dart
// lib/services/local_auth_service.dart
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class LocalAuthService {
  static const String _keyUser = 'auth_user';
  static const String _keyPasswordHash = 'auth_password_hash';
  static const String _keyIsLoggedIn = 'auth_is_logged_in';

  /// تجزئة كلمة المرور
  static String _hashPassword(String password) {
    final bytes = utf8.encode(password);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  /// تسجيل الدخول
  static Future<bool> signIn(String username, String password) async {
    final prefs = await SharedPreferences.getInstance();
    
    final savedUsername = prefs.getString(_keyUser);
    final savedHash = prefs.getString(_keyPasswordHash);
    
    if (savedUsername == null || savedHash == null) {
      // أول تسجيل دخول
      await _createUser(username, password);
      return true;
    }
    
    if (username == savedUsername && _hashPassword(password) == savedHash) {
      await prefs.setBool(_keyIsLoggedIn, true);
      return true;
    }
    
    return false;
  }

  /// إنشاء مستخدم جديد
  static Future<void> _createUser(String username, String password) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyUser, username);
    await prefs.setString(_keyPasswordHash, _hashPassword(password));
    await prefs.setBool(_keyIsLoggedIn, true);
  }

  /// تسجيل الخروج
  static Future<void> signOut() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyIsLoggedIn, false);
  }

  /// التحقق من حالة المصادقة
  static Future<bool> isAuthenticated() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyIsLoggedIn) ?? false;
  }

  /// تغيير كلمة المرور
  static Future<bool> changePassword(String oldPassword, String newPassword) async {
    final prefs = await SharedPreferences.getInstance();
    final savedHash = prefs.getString(_keyPasswordHash);
    
    if (_hashPassword(oldPassword) != savedHash) {
      return false;
    }
    
    await prefs.setString(_keyPasswordHash, _hashPassword(newPassword));
    return true;
  }
}
```

---

## 🛡️ تشفير البيانات الحساسة

```dart
// lib/services/encryption_service.dart
import 'package:encrypt/encrypt.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EncryptionService {
  static final _key = Key.fromUtf8('your-32-char-key-here!!!!!!!!!');
  static final _iv = IV.fromLength(16);
  static final _encrypter = Encrypter(AES(_key));

  /// تشفير نص
  static String encrypt(String text) {
    return _encrypter.encrypt(text, iv: _iv).base64;
  }

  /// فك تشفير نص
  static String decrypt(String encrypted) {
    return _encrypter.decrypt64(encrypted, iv: _iv);
  }

  /// حفظ قيمة مشفرة
  static Future<void> setEncrypted(String key, String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, encrypt(value));
  }

  /// قراءة قيمة مشفرة
  static Future<String?> getEncrypted(String key) async {
    final prefs = await SharedPreferences.getInstance();
    final encrypted = prefs.getString(key);
    if (encrypted == null) return null;
    return decrypt(encrypted);
  }
}
```

---

## 📋 الصلاحيات

### أنظمة الأدوار

| الدور | الصلاحيات |
|-------|-----------|
| **Admin** | كل الصلاحيات |
| **Manager** | المخزون، التقارير، العملاء |
| **Cashier** | POS فقط |

```dart
// lib/models/user_role.dart
enum UserRole {
  admin,
  manager,
  cashier;

  bool get canManageInventory => this == admin || this == manager;
  bool get canViewReports => this == admin || this == manager;
  bool get canManageUsers => this == admin;
  bool get canUsePOS => true;
}

// lib/providers/auth_provider.dart
final userRoleProvider = StateProvider<UserRole>((ref) => UserRole.cashier);
```

---

## 💾 النسخ الاحتياطي

```dart
// lib/services/backup_service.dart
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class BackupService {
  final SupabaseClient _supabase = Supabase.instance.client;

  /// نسخ احتياطي لقاعدة البيانات
  Future<bool> backupDatabase() async {
    try {
      final dbFile = await _getDatabaseFile();
      if (!await dbFile.exists()) {
        return false;
      }

      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final fileName = 'backup_$timestamp.db';

      await _supabase.storage
        .from('backups')
        .upload(fileName, dbFile);

      return true;
    } catch (e) {
      print('خطأ في النسخ الاحتياطي: $e');
      return false;
    }
  }

  /// استعادة قاعدة البيانات
  Future<bool> restoreDatabase(String backupFileName) async {
    try {
      final response = await _supabase.storage
        .from('backups')
        .download(backupFileName);

      final dbFile = await _getDatabaseFile();
      await dbFile.writeAsBytes(response);

      return true;
    } catch (e) {
      print('خطأ في الاستعادة: $e');
      return false;
    }
  }

  /// قائمة النسخ الاحتياطية
  Future<List<String>> listBackups() async {
    try {
      final response = await _supabase.storage
        .from('backups')
        .list();

      return response.map((file) => file.name).toList();
    } catch (e) {
      return [];
    }
  }

  Future<File> _getDatabaseFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/erp_database.db');
  }
}
```

---

## 📊 سجل العمليات (Audit Log)

```dart
// lib/data/database/tables/audit_log.dart
import 'package:drift/drift.dart';

class AuditLogs extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get action => text()(); // create, update, delete, login
  TextColumn get entityType => text()(); // product, invoice, customer
  IntColumn get entityId => integer().nullable()();
  TextColumn get oldValues => text().nullable()();
  TextColumn get newValues => text().nullable()();
  TextColumn get userId => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

// lib/services/audit_service.dart
class AuditService {
  final AppDatabase _db;

  AuditService(this._db);

  Future<void> log({
    required String action,
    required String entityType,
    int? entityId,
    Map<String, dynamic>? oldValues,
    Map<String, dynamic>? newValues,
    String? userId,
  }) async {
    await _db.into(_db.auditLogs).insert(
      AuditLogsCompanion(
        action: Value(action),
        entityType: Value(entityType),
        entityId: Value(entityId),
        oldValues: Value(oldValues?.toString()),
        newValues: Value(newValues?.toString()),
        userId: Value(userId),
      ),
    );
  }
}
```

---

## 🚨 قائمة التحقق الأمنية

- [x] تشفير كلمات المرور (SHA-256)
- [x] تسجيل الدخول المحلي
- [x] أدوار وصلاحيات
- [x] تشفير البيانات الحساسة
- [x] نسخ احتياطي مشفر
- [x] سجل عمليات
- [x] RLS في Supabase
- [x] JWT للمزامنة

---

**الوثيقة:** الأمان  
**الإصدار:** 1.0  
**تاريخ التحديث:** 2026-03-08
