# 🧪 خطة الاختبار

## 🎯 مقدمة

يقدم هذا المستند استراتيجية الاختبار الشاملة للتطبيق.

---

## 🏛️ أنواع الاختبار

```mermaid
flowchart TB
    subgraph Testing["اختبارات"]
        Unit[Unit Tests]
        Widget[Widget Tests]
        Integration[Integration Tests]
        E2E[E2E Tests]
    end
    
    subgraph Coverage["التغطية"]
        Logic[منطق الأعمال]
        UI[واجهات]
        Flow[تدفقات]
    end
    
    Unit --> Logic
    Widget --> UI
    Integration --> Flow
    E2E --> Flow
```

---

## 📝 خطة الاختبار

### 1️⃣ Unit Tests

```dart
// test/providers/cart_provider_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:erp/providers/cart_provider.dart';
import 'package:erp/data/models/product_model.dart';

void main() {
  group('CartProvider', () {
    late ProviderContainer container;
    late CartNotifier cart;

    setUp(() {
      container = ProviderContainer();
      cart = container.read(cartProvider.notifier);
    });

    tearDown(() {
      container.dispose();
    });

    test('إضافة منتج للسلة', () {
      final product = Product(
        id: 1,
        name: 'تفاح',
        salePrice: 5.0,
      );

      cart.addItem(product, quantity: 2);

      final state = container.read(cartProvider);
      expect(state.length, 1);
      expect(state.first.quantity, 2);
      expect(state.first.product.name, 'تفاح');
    });

    test('تحديث كمية المنتج', () {
      final product = Product(id: 1, name: 'تفاح', salePrice: 5.0);
      cart.addItem(product, quantity: 1);
      cart.updateQuantity(1, 5);

      final state = container.read(cartProvider);
      expect(state.first.quantity, 5);
    });

    test('حساب الإجمالي', () {
      cart.addItem(Product(id: 1, name: 'تفاح', salePrice: 10.0), quantity: 2);
      cart.addItem(Product(id: 2, name: 'حليب', salePrice: 5.0), quantity: 1);

      expect(cart.subtotal, 25.0);
      expect(cart.tax, 3.75); // 15%
      expect(cart.total, 28.75);
    });

    test('إفراغ السلة', () {
      cart.addItem(Product(id: 1, name: 'تفاح', salePrice: 5.0));
      cart.clear();

      final state = container.read(cartProvider);
      expect(state.isEmpty, true);
    });
  });
}
```

### 2️⃣ Widget Tests

```dart
// test/widgets/product_card_test.dart
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:erp/widgets/pos/product_card.dart';
import 'package:erp/data/models/product_model.dart';

void main() {
  group('ProductCard', () {
    testWidgets('عرض معلومات المنتج', (tester) async {
      final product = Product(
        id: 1,
        name: 'تفاح أحمر',
        salePrice: 5.50,
        stockQuantity: 100,
      );

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: ProductCard(
              product: product,
              onTap: () {},
            ),
          ),
        ),
      );

      expect(find.text('تفاح أحمر'), findsOneWidget);
      expect(find.text('5.50 ريال'), findsOneWidget);
    });

    testWidgets('استدعاء onTap عند الضغط', (tester) async {
      bool tapped = false;
      final product = Product(id: 1, name: 'تفاح', salePrice: 5.0);

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: ProductCard(
              product: product,
              onTap: () => tapped = true,
            ),
          ),
        ),
      );

      await tester.tap(find.byType(ProductCard));
      expect(tapped, true);
    });
  });
}
```

### 3️⃣ Integration Tests

```dart
// integration_test/app_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:erp/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('تدفق كامل البيع', () {
    testWidgets('إتمام عملية بيع', (tester) async {
      app.main();
      await tester.pumpAndSettle();

      // تسجيل الدخول
      await tester.enterText(find.byType(TextField).first, 'admin');
      await tester.enterText(find.byType(TextField).last, 'password');
      await tester.tap(find.text('تسجيل الدخول'));
      await tester.pumpAndSettle();

      // الذهاب لشاشة POS
      await tester.tap(find.text('نقطة البيع'));
      await tester.pumpAndSettle();

      // إضافة منتج
      await tester.enterText(find.byType(TextField).first, '123456');
      await tester.testTextInput.receiveAction(TextInputAction.done);
      await tester.pumpAndSettle();

      // التحقق من وجود المنتج في السلة
      expect(find.text('تفاح أحمر'), findsOneWidget);

      // إتمام الدفع
      await tester.tap(find.text('إتمام الدفع'));
      await tester.pumpAndSettle();

      // اختيار طريقة الدفع
      await tester.tap(find.text('نقدي'));
      await tester.pumpAndSettle();

      // إدخال المبلغ
      await tester.enterText(find.byType(TextField).last, '50');
      await tester.tap(find.text('تأكيد'));
      await tester.pumpAndSettle();

      // التحقق من نجاح البيع
      expect(find.text('تم إتمام البيع بنجاح'), findsOneWidget);
    });
  });
}
```

---

## 📊 تغطية الاختبار

| المكون | Unit | Widget | Integration | الهدف |
|--------|------|--------|-------------|-------|
| Providers | ✅ | - | - | 80% |
| Repositories | ✅ | - | - | 80% |
| Services | ✅ | - | - | 70% |
| Widgets | - | ✅ | - | 60% |
| Screens | - | - | ✅ | 50% |
| Flows | - | - | ✅ | 30% |

---

## 🚀 تشغيل الاختبارات

```bash
# Unit Tests
flutter test

# Widget Tests
flutter test test/widgets/

# Integration Tests
flutter test integration_test/

# مع تغطية
flutter test --coverage
genhtml coverage/lcov.info -o coverage/html
```

---

## 📝 قائمة الاختبارات

### اختبارات POS

- [ ] إضافة منتج بالباركود
- [ ] إضافة منتج بالبحث
- [ ] تحديث كمية المنتج
- [ ] حذف منتج من السلة
- [ ] تطبيق خصم
- [ ] الدفع النقدي
- [ ] الدفع بالبطاقة
- [ ] طباعة الفاتورة

### اختبارات المخزون

- [ ] إضافة منتج جديد
- [ ] تعديل منتج
- [ ] حذف منتج
- [ ] البحث عن منتج
- [ ] عرض المنتجات النافدة

### اختبارات المزامنة

- [ ] مزامنة عند توفر الإنترنت
- [ ] عمل Offline
- [ ] حل تعارض البيانات
- [ ] النسخ الاحتياطي

---

**الوثيقة:** خطة الاختبار  
**الإصدار:** 1.0  
**تاريخ التحديث:** 2026-03-08
