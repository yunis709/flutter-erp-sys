# 🧩 الوحدات النظامية

## 🎯 مقدمة

يحتوي النظام على وحدات متكاملة تعمل معاً لتوفير حل شامل لإدارة المحلات التجارية.

---

## 🏛️ هيكل الوحدات

```mermaid
flowchart TB
    subgraph Core["النواة"]
        DB[(SQLite Database)]
        Sync[Sync Engine]
    end
    
    subgraph Modules["الوحدات"]
        POS[نقاط البيع]
        INV[المخزون]
        ACC[المحاسبة]
        CUS[العملاء]
        SUP[الموردين]
        REP[التقارير]
    end
    
    subgraph External["الخارجي"]
        Printer[طابعة]
        Scanner[باركود]
        Cloud[Supabase]
    end
    
    Core --> Modules
    POS --> Printer
    POS --> Scanner
    Sync -.-> Cloud
```

---

## 📦 الوحدات الرئيسية

### 1️⃣ نقاط البيع (POS Module)

```mermaid
flowchart TB
    subgraph POS["POS Module"]
        Screen[POS Screen]
        Cart[Cart Provider]
        Payment[Payment Handler]
        Printer[Print Service]
    end
    
    subgraph Data["البيانات"]
        Products[Products Table]
        Invoices[Invoices Table]
        Inventory[Inventory Table]
    end
    
    Screen --> Cart
    Cart --> Payment
    Payment --> Printer
    Cart --> Products
    Payment --> Invoices
    Payment --> Inventory
```

**المكونات:**
- **POS Screen**: واجهة البيع الرئيسية
- **Cart Provider**: إدارة سلة المشتريات (Riverpod)
- **Payment Handler**: معالجة الدفع
- **Print Service**: طباعة الفواتير

**التكامل:**
- يقرأ من: Products, Customers
- يكتب في: Invoices, InvoiceItems, InventoryMovements, JournalEntries

---

### 2️⃣ المخزون (Inventory Module)

```mermaid
flowchart LR
    A[Products Screen] --> B[Product Form]
    A --> C[Stock Movements]
    C --> D[Inventory Report]
    B --> E[SQLite]
    C --> E
    D --> E
```

**المكونات:**
- **Products Screen**: قائمة المنتجات
- **Product Form**: إضافة/تعديل منتج
- **Stock Movements**: حركات المخزون
- **Inventory Report**: تقرير المخزون

**الجداول:**
```sql
-- products
- id, name, barcode, sale_price, cost_price, stock_quantity

-- inventory_movements
- id, product_id, type (in/out), quantity, date, reference
```

---

### 3️⃣ المحاسبة (Accounting Module)

```mermaid
flowchart TB
    subgraph ACC["Accounting"]
        JE[Journal Entries]
        GL[General Ledger]
        COA[Chart of Accounts]
    end
    
    subgraph Auto["توليد آلي"]
        Sale[من المبيعات]
        Purchase[من المشتريات]
    end
    
    Auto --> JE
    JE --> GL
    COA --> JE
```

**المكونات:**
- **Chart of Accounts**: شجرة الحسابات
- **Journal Entries**: القيود اليومية
- **General Ledger**: دفتر الأستاذ

**الجداول:**
```sql
-- accounts
- id, code, name, type (asset/liability/equity/revenue/expense)

-- journal_entries
- id, date, account_id, debit, credit, description, reference
```

**التوليد الآلي:**
| العملية | القيد |
|---------|-------|
| بيع نقدي | من: الصندوق / إلى: المبيعات |
| بيع آجل | من: ذمم العملاء / إلى: المبيعات |
| شراء | من: المشتريات / إلى: ذمم الموردين |

---

### 4️⃣ العملاء (Customers Module)

```mermaid
flowchart LR
    A[Customers List] --> B[Customer Details]
    B --> C[Account Statement]
    B --> D[Loyalty Points]
    C --> E[Payments]
```

**المكونات:**
- **Customers List**: قائمة العملاء
- **Customer Details**: تفاصيل العميل
- **Account Statement**: كشف حساب
- **Loyalty Points**: النقاط (إختياري)

**الجداول:**
```sql
-- customers
- id, name, phone, email, credit_limit, balance, points

-- customer_payments
- id, customer_id, amount, date, method
```

---

### 5️⃣ الموردين (Suppliers Module)

```mermaid
flowchart LR
    A[Suppliers List] --> B[Supplier Details]
    B --> C[Purchase Invoices]
    B --> D[Account Statement]
```

**المكونات:**
- **Suppliers List**: قائمة الموردين
- **Purchase Invoices**: فواتير الشراء
- **Account Statement**: كشف حساب

**الجداول:**
```sql
-- suppliers
- id, name, phone, email, balance

-- purchase_invoices
- id, supplier_id, total, date, paid_amount
```

---

### 6️⃣ التقارير (Reports Module)

```mermaid
mindmap
  root((التقارير))
    مبيعات
      يومي
      شهري
      حسب المنتج
      حسب العميل
    مخزون
      حركات
      قيمة
      نافد
      راكد
    مالية
      دخل
      ذمم عملاء
      ذمم موردين
```

**المكونات:**
- **Sales Reports**: تقارير المبيعات
- **Inventory Reports**: تقارير المخزون
- **Financial Reports**: تقارير مالية
- **Export**: تصدير PDF/Excel

---

## 🔗 التكامل بين الوحدات

### تدفق البيانات

```mermaid
sequenceDiagram
    participant POS as POS Module
    participant INV as Inventory Module
    participant ACC as Accounting Module
    participant DB as SQLite
    
    POS->>DB: حفظ فاتورة
    POS->>INV: خصم من المخزون
    INV->>DB: تحديث الكمية
    POS->>ACC: تسجيل قيد
    ACC->>DB: حفظ القيد
```

---

## 📊 جدول الوحدات

| الوحدة | الحالة | الأولوية | التكامل |
|--------|--------|----------|---------|
| POS | 🔄 قيد التطوير | عالية | الكل |
| Inventory | 🔄 قيد التطوير | عالية | POS, Reports |
| Accounting | 🔄 قيد التطوير | عالية | POS, Purchase |
| Customers | 🔄 قيد التطوير | متوسطة | POS |
| Suppliers | 🔄 قيد التطوير | متوسطة | Purchase |
| Reports | 🔄 قيد التطوير | متوسطة | الكل |

---

**الوثيقة:** الوحدات النظامية  
**الإصدار:** 1.0  
**تاريخ التحديث:** 2026-03-08
