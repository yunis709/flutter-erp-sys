# 🔄 نظام المزامنة

## 🎯 مقدمة

نظام المزامنة يربط قاعدة البيانات المحلية (SQLite) مع Supabase للنسخ الاحتياطي والمزامنة عند توفر الإنترنت.

---

## 🏛️ بنية المزامنة

```mermaid
flowchart TB
    subgraph Local["💻 التطبيق المحلي"]
        App[Flutter App]
        SQLite[(SQLite)]
        Sync[Sync Engine]
    end
    
    subgraph Cloud["☁️ Supabase"]
        Auth[Authentication]
        DB[(PostgreSQL)]
        Edge[Edge Functions]
        Realtime[Realtime]
    end
    
    App --> SQLite
    App --> Sync
    Sync -.->|HTTP| Auth
    Sync -.->|REST API| DB
    Sync -.->|WebSocket| Realtime
```

---

## 📋 استراتيجية المزامنة

### المبدأ: Local-First

```
┌─────────────────────────────────────────────────────────────┐
│                    استراتيجية المزامنة                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1️⃣ كل البيانات تُحفظ محلياً أولاً (SQLite)                 │
│  2️⃣ عند توفر الإنترنت، تُرفع التغييرات للسحابة              │
│  3️⃣ المزامنة تلقائية كل 24 ساعة أو يدوياً                   │
│  4️⃣ حل التعارض: "الأحدث يفوز" (Last Write Wins)             │
│  5️⃣ النسخ الاحتياطي: يومي في الساعة 2:00 صباحاً             │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔧 خدمة المزامنة

```dart
// lib/services/sync_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';
import '../data/database/database.dart';

class SyncService {
  final SupabaseClient _supabase;
  final AppDatabase _db;
  
  SyncService(this._supabase, this._db);

  /// التحقق من توفر الإنترنت
  Future<bool> isOnline() async {
    try {
      final result = await _supabase.from('health').select().limit(1).timeout(
        const Duration(seconds: 5),
        onTimeout: () => throw TimeoutException('Connection timeout'),
      );
      return true;
    } catch (e) {
      return false;
    }
  }

  /// مزامنة كاملة
  Future<SyncResult> syncAll() async {
    if (!await isOnline()) {
      return SyncResult.offline();
    }

    try {
      // 1️⃣ رفع التغييرات المحلية
      await _pushProducts();
      await _pushInvoices();
      await _pushCustomers();
      await _pushInventoryMovements();
      
      // 2️⃣ سحب التحديثات من السحابة
      await _pullProducts();
      await _pullCustomers();
      
      // 3️⃣ تحديث وقت آخر مزامنة
      await _updateLastSyncTime();
      
      return SyncResult.success();
    } catch (e) {
      return SyncResult.error(e.toString());
    }
  }

  /// رفع المنتجات غير المتزامنة
  Future<void> _pushProducts() async {
    final unsynced = await _db.select(_db.products)
      ..where((p) => p.isSynced.equals(false))
      ..get();

    for (final product in unsynced) {
      try {
        await _supabase.from('products').upsert({
          'id': product.id,
          'name': product.name,
          'barcode': product.barcode,
          'sku': product.sku,
          'sale_price': product.salePrice,
          'cost_price': product.costPrice,
          'stock_quantity': product.stockQuantity,
          'min_stock_level': product.minStockLevel,
          'is_active': product.isActive,
          'created_at': product.createdAt.toIso8601String(),
          'updated_at': DateTime.now().toIso8601String(),
        });

        // تحديث حالة المزامنة
        await _db.update(_db.products)
          ..where((p) => p.id.equals(product.id))
          ..write(const ProductsCompanion(isSynced: Value(true)));
      } catch (e) {
        print('خطأ في رفع المنتج ${product.id}: $e');
      }
    }
  }

  /// سحب المنتجات من السحابة
  Future<void> _pullProducts() async {
    final lastSync = await _getLastSyncTime();
    
    final remoteProducts = await _supabase
      .from('products')
      .select()
      .gt('updated_at', lastSync.toIso8601String());

    for (final remote in remoteProducts) {
      await _db.into(_db.products).insertOnConflictUpdate(
        ProductsCompanion(
          id: Value(remote['id']),
          name: Value(remote['name']),
          barcode: Value(remote['barcode']),
          sku: Value(remote['sku']),
          salePrice: Value(remote['sale_price']),
          costPrice: Value(remote['cost_price']),
          stockQuantity: Value(remote['stock_quantity']),
          minStockLevel: Value(remote['min_stock_level']),
          isActive: Value(remote['is_active']),
          isSynced: const Value(true),
          createdAt: Value(DateTime.parse(remote['created_at'])),
          updatedAt: Value(DateTime.parse(remote['updated_at'])),
        ),
      );
    }
  }

  /// جدولة المزامنة التلقائية
  void scheduleAutoSync() {
    // مزامنة يومية في الساعة 2:00 صباحاً
    Timer.periodic(const Duration(hours: 1), (_) async {
      final now = DateTime.now();
      if (now.hour == 2 && await isOnline()) {
        await syncAll();
      }
    });
  }

  Future<DateTime> _getLastSyncTime() async {
    // قراءة من SharedPreferences
    final prefs = await SharedPreferences.getInstance();
    final timestamp = prefs.getInt('last_sync');
    return timestamp != null 
      ? DateTime.fromMillisecondsSinceEpoch(timestamp)
      : DateTime(2000);
  }

  Future<void> _updateLastSyncTime() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('last_sync', DateTime.now().millisecondsSinceEpoch);
  }
}

/// نتيجة المزامنة
class SyncResult {
  final bool success;
  final bool isOffline;
  final String? error;
  final DateTime? timestamp;

  SyncResult._({
    required this.success,
    this.isOffline = false,
    this.error,
    this.timestamp,
  });

  factory SyncResult.success() => SyncResult._(
    success: true,
    timestamp: DateTime.now(),
  );

  factory SyncResult.offline() => SyncResult._(
    success: false,
    isOffline: true,
  );

  factory SyncResult.error(String message) => SyncResult._(
    success: false,
    error: message,
  );
}
```

---

## 📊 جدول المزامنة في Supabase

```sql
-- جدول تتبع المزامنة
CREATE TABLE sync_tracking (
  id SERIAL PRIMARY KEY,
  table_name TEXT NOT NULL,
  record_id INTEGER NOT NULL,
  operation TEXT NOT NULL, -- insert, update, delete
  synced_at TIMESTAMP DEFAULT NOW(),
  device_id TEXT
);

-- فهرس للبحث
CREATE INDEX idx_sync_tracking_table ON sync_tracking(table_name, record_id);
```

---

## 🔐 إعدادات Supabase

### 1. إنشاء مشروع

```bash
# أو عبر واجهة Supabase
# https://supabase.com/dashboard
```

### 2. الجداول المطلوبة

```sql
-- المنتجات
CREATE TABLE products (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  barcode TEXT UNIQUE,
  sku TEXT,
  sale_price DECIMAL(10,2) DEFAULT 0,
  cost_price DECIMAL(10,2) DEFAULT 0,
  stock_quantity DECIMAL(10,2) DEFAULT 0,
  min_stock_level DECIMAL(10,2) DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- الفواتير
CREATE TABLE invoices (
  id SERIAL PRIMARY KEY,
  invoice_number TEXT UNIQUE NOT NULL,
  customer_id INTEGER,
  user_id INTEGER,
  subtotal DECIMAL(10,2) DEFAULT 0,
  discount DECIMAL(10,2) DEFAULT 0,
  tax DECIMAL(10,2) DEFAULT 0,
  total DECIMAL(10,2) DEFAULT 0,
  paid_amount DECIMAL(10,2) DEFAULT 0,
  payment_method TEXT,
  payment_status TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Row Level Security (RLS)
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;

-- سياسة: المستخدم يرى بياناته فقط
CREATE POLICY "Users can only access their own data" ON products
  FOR ALL USING (auth.uid() = user_id);
```

### 3. إعدادات Flutter

```dart
// lib/main.dart
import 'package:supabase_flutter/supabase_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await Supabase.initialize(
    url: 'https://your-project.supabase.co',
    anonKey: 'your-anon-key',
  );
  
  runApp(const MyApp());
}
```

---

## 📈 تكلفة Supabase

| الخطة | السعر | التخزين | الاتصالات |
|-------|-------|---------|-----------|
| **Free** | $0 | 500 MB | 200K/month |
| Pro | $25 | 8 GB | Unlimited |

**للمحلات الصغيرة: Free Tier كافي تماماً**

---

**الوثيقة:** نظام المزامنة  
**الإصدار:** 1.0  
**تاريخ التحديث:** 2026-03-08
