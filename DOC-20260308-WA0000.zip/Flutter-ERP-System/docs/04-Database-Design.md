# 💾 تصميم قاعدة البيانات

## 🎯 مقدمة

يستخدم النظام **SQLite** كقاعدة بيانات محلية مع **Drift ORM** للتعامل معها في Flutter.

---

## 🏛️ هيكل قاعدة البيانات

```mermaid
erDiagram
    products ||--o{ inventory_movements : has
    products ||--o{ invoice_items : included_in
    products ||--o{ purchase_items : included_in
    
    customers ||--o{ invoices : has
    customers ||--o{ customer_payments : has
    
    suppliers ||--o{ purchase_invoices : has
    suppliers ||--o{ supplier_payments : has
    
    invoices ||--o{ invoice_items : contains
    invoices ||--o{ journal_entries : generates
    
    purchase_invoices ||--o{ purchase_items : contains
    purchase_invoices ||--o{ journal_entries : generates
    
    accounts ||--o{ journal_entries : has
    
    users ||--o{ invoices : creates
    users ||--o{ purchase_invoices : creates

    products {
        int id PK
        string name
        string barcode
        string sku
        real sale_price
        real cost_price
        real stock_quantity
        real min_stock_level
        int category_id FK
        bool is_active
        datetime created_at
        datetime updated_at
    }
    
    customers {
        int id PK
        string name
        string phone
        string email
        real credit_limit
        real balance
        int points
        bool is_active
    }
    
    suppliers {
        int id PK
        string name
        string phone
        string email
        real balance
        bool is_active
    }
    
    invoices {
        int id PK
        string invoice_number UK
        int customer_id FK
        int user_id FK
        real subtotal
        real discount
        real tax
        real total
        real paid_amount
        string payment_method
        string payment_status
        datetime created_at
    }
    
    invoice_items {
        int id PK
        int invoice_id FK
        int product_id FK
        real quantity
        real unit_price
        real total
    }
    
    purchase_invoices {
        int id PK
        string invoice_number UK
        int supplier_id FK
        int user_id FK
        real subtotal
        real tax
        real total
        real paid_amount
        datetime created_at
    }
    
    purchase_items {
        int id PK
        int purchase_invoice_id FK
        int product_id FK
        real quantity
        real unit_price
        real total
    }
    
    inventory_movements {
        int id PK
        int product_id FK
        string type
        real quantity
        string reference_type
        int reference_id
        datetime created_at
    }
    
    accounts {
        int id PK
        string code UK
        string name
        string type
        int parent_id FK
        real balance
        bool is_active
    }
    
    journal_entries {
        int id PK
        int account_id FK
        datetime date
        real debit
        real credit
        string description
        string reference_type
        int reference_id
    }
    
    users {
        int id PK
        string username UK
        string password_hash
        string full_name
        string role
        bool is_active
    }
```

---

## 🗄️ تعريف الجداول (Drift)

### جدول المنتجات

```dart
// lib/data/database/tables/products.dart
import 'package:drift/drift.dart';

class Products extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text().withLength(min: 1, max: 200)();
  TextColumn get barcode => text().nullable().withLength(max: 50)();
  TextColumn get sku => text().nullable().withLength(max: 50)();
  RealColumn get salePrice => real().withDefault(const Constant(0))();
  RealColumn get costPrice => real().withDefault(const Constant(0))();
  RealColumn get stockQuantity => real().withDefault(const Constant(0))();
  RealColumn get minStockLevel => real().withDefault(const Constant(0))();
  IntColumn get categoryId => integer().nullable()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  
  @override
  List<String> get customConstraints => [
    'UNIQUE(barcode)',
  ];
}
```

### جدول الفواتير

```dart
// lib/data/database/tables/invoices.dart
import 'package:drift/drift.dart';

class Invoices extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get invoiceNumber => text().withLength(max: 50)();
  IntColumn get customerId => integer().nullable().references(Customers, #id)();
  IntColumn get userId => integer().references(Users, #id)();
  RealColumn get subtotal => real().withDefault(const Constant(0))();
  RealColumn get discount => real().withDefault(const Constant(0))();
  RealColumn get tax => real().withDefault(const Constant(0))();
  RealColumn get total => real().withDefault(const Constant(0))();
  RealColumn get paidAmount => real().withDefault(const Constant(0))();
  TextColumn get paymentMethod => text().withLength(max: 20)(); // cash, card, credit
  TextColumn get paymentStatus => text().withLength(max: 20)(); // paid, partial, unpaid
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  
  @override
  List<String> get customConstraints => [
    'UNIQUE(invoice_number)',
  ];
}

class InvoiceItems extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get invoiceId => integer().references(Invoices, #id, onDelete: KeyAction.cascade)();
  IntColumn get productId => integer().references(Products, #id)();
  RealColumn get quantity => real().withDefault(const Constant(1))();
  RealColumn get unitPrice => real().withDefault(const Constant(0))();
  RealColumn get total => real().withDefault(const Constant(0))();
}
```

### جدول العملاء

```dart
// lib/data/database/tables/customers.dart
import 'package:drift/drift.dart';

class Customers extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text().withLength(min: 1, max: 200)();
  TextColumn get phone => text().nullable().withLength(max: 20)();
  TextColumn get email => text().nullable().withLength(max: 100)();
  RealColumn get creditLimit => real().withDefault(const Constant(0))();
  RealColumn get balance => real().withDefault(const Constant(0))();
  IntColumn get points => integer().withDefault(const Constant(0))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

class CustomerPayments extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get customerId => integer().references(Customers, #id)();
  RealColumn get amount => real().withDefault(const Constant(0))();
  TextColumn get method => text().withLength(max: 20)();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}
```

### جدول المخزون

```dart
// lib/data/database/tables/inventory.dart
import 'package:drift/drift.dart';

class InventoryMovements extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get productId => integer().references(Products, #id)();
  TextColumn get type => text().withLength(max: 10)(); // in, out, adjustment
  RealColumn get quantity => real()();
  TextColumn get referenceType => text().nullable().withLength(max: 50)(); // invoice, purchase, adjustment
  IntColumn get referenceId => integer().nullable()();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}
```

### جدول المحاسبة

```dart
// lib/data/database/tables/accounting.dart
import 'package:drift/drift.dart';

class Accounts extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get code => text().withLength(max: 20)();
  TextColumn get name => text().withLength(max: 100)();
  TextColumn get type => text().withLength(max: 20)(); // asset, liability, equity, revenue, expense
  IntColumn get parentId => integer().nullable()();
  RealColumn get balance => real().withDefault(const Constant(0))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
}

class JournalEntries extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get accountId => integer().references(Accounts, #id)();
  DateTimeColumn get date => dateTime()();
  RealColumn get debit => real().withDefault(const Constant(0))();
  RealColumn get credit => real().withDefault(const Constant(0))();
  TextColumn get description => text().nullable()();
  TextColumn get referenceType => text().nullable().withLength(max: 50)();
  IntColumn get referenceId => integer().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}
```

### جدول المستخدمين

```dart
// lib/data/database/tables/users.dart
import 'package:drift/drift.dart';

class Users extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get username => text().withLength(max: 50)();
  TextColumn get passwordHash => text().withLength(max: 255)();
  TextColumn get fullName => text().withLength(max: 100)();
  TextColumn get role => text().withLength(max: 20)(); // admin, cashier, manager
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get lastLogin => dateTime().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  
  @override
  List<String> get customConstraints => [
    'UNIQUE(username)',
  ];
}
```

---

## 🗂️ قاعدة البيانات الرئيسية

```dart
// lib/data/database/database.dart
import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';

import 'tables/products.dart';
import 'tables/invoices.dart';
import 'tables/customers.dart';
import 'tables/suppliers.dart';
import 'tables/inventory.dart';
import 'tables/accounting.dart';
import 'tables/users.dart';

part 'database.g.dart';

@DriftDatabase(tables: [
  Products,
  Invoices,
  InvoiceItems,
  Customers,
  CustomerPayments,
  Suppliers,
  SupplierPayments,
  PurchaseInvoices,
  PurchaseItems,
  InventoryMovements,
  Accounts,
  JournalEntries,
  Users,
])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  @override
  int get schemaVersion => 1;

  static QueryExecutor _openConnection() {
    return driftDatabase(name: 'erp_database');
  }
}
```

---

## 📊 الفهارس (Indexes)

```sql
-- فهارس للبحث السريع
CREATE INDEX idx_products_barcode ON products(barcode);
CREATE INDEX idx_products_name ON products(name);
CREATE INDEX idx_invoices_date ON invoices(created_at);
CREATE INDEX idx_invoices_customer ON invoices(customer_id);
CREATE INDEX idx_inventory_product ON inventory_movements(product_id);
CREATE INDEX idx_journal_entries_date ON journal_entries(date);
CREATE INDEX idx_journal_entries_account ON journal_entries(account_id);
```

---

## 💾 حجم قاعدة البيانات المتوقع

| البيانات | عدد السجلات | الحجم التقريبي |
|----------|-------------|----------------|
| المنتجات | 5,000 | 2 MB |
| الفواتير/سنة | 50,000 | 10 MB |
| عملاء | 2,000 | 1 MB |
| حركات المخزون | 200,000 | 15 MB |
| **الإجمالي** | | **~30 MB** |

---

**الوثيقة:** تصميم قاعدة البيانات  
**الإصدار:** 1.0  
**تاريخ التحديث:** 2026-03-08
