# 🚀 خطة النشر

## 🎯 مقدمة

يقدم هذا المستند خطوات بناء ونشر تطبيق Flutter Desktop للعملاء.

---

## 🏛️ خيارات النشر

```mermaid
flowchart TB
    subgraph Build["بناء التطبيق"]
        Windows[Windows EXE/MSI]
    end
    
    subgraph Distribution["التوزيع"]
        Direct[تحميل مباشر]
        Installer[مثبت تلقائي]
    end
    
    subgraph Update["التحديثات"]
        Manual[يدوي]
        Auto[تلقائي]
    end
    
    Build --> Distribution --> Update
```

---

## 🖥️ بناء للـ Windows

### 1. إعدادات Windows

```yaml
# pubspec.yaml
flutter:
  windows:
    generate: true
```

### 2. بناء نسخة الإصدار

```bash
# تنظيف
flutter clean

# تثبيت التبعيات
flutter pub get

# بناء للـ Windows
flutter build windows --release
```

### 3. مخرجات البناء

```
build/windows/x64/runner/Release/
├── flutter_erp.exe          # ملف التنفيذي
├── flutter_windows.dll      # مكتبات Flutter
├── icudtl.dat               # بيانات ICU
└── data/                    # بيانات التطبيق
    ├── flutter_assets/      # أصول Flutter
    └── icu/                 # بيانات ICU
```

---

## 📦 إنشاء مثبت (Installer)

### باستخدام Inno Setup

```pascal
; setup.iss
#define MyAppName "ERP System"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Your Company"
#define MyAppExeName "flutter_erp.exe"

[Setup]
AppId={{YOUR-APP-ID}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DisableProgramGroupPage=yes
OutputDir=installer
OutputBaseFilename=ERP-System-Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern

[Languages]
Name: "arabic"; MessagesFile: "compiler:Languages\\Arabic.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "build\windows\x64\runner\Release\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: "build\windows\x64\runner\Release\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent
```

### بناء المثبت

```bash
# تثبيت Inno Setup
# https://jrsoftware.org/isdl.php

# بناء المثبت
"C:\Program Files (x86)\Inno Setup 6\ISCC.exe" setup.iss
```

---

## 🔄 نظام التحديثات

```dart
// lib/services/update_service.dart
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:version/version.dart';

class UpdateService {
  static const String versionUrl = 'https://your-server.com/version.json';
  static const String downloadUrl = 'https://your-server.com/downloads/';

  /// التحقق من وجود تحديث
  static Future<UpdateInfo?> checkForUpdate() async {
    try {
      final response = await http.get(Uri.parse(versionUrl));
      if (response.statusCode != 200) return null;

      final data = jsonDecode(response.body);
      final latestVersion = Version.parse(data['version']);
      final currentVersion = Version.parse(await _getCurrentVersion());

      if (latestVersion > currentVersion) {
        return UpdateInfo(
          version: data['version'],
          downloadUrl: data['download_url'],
          releaseNotes: data['release_notes'],
        );
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  /// تحميل التحديث
  static Future<String?> downloadUpdate(String url) async {
    try {
      final response = await http.get(Uri.parse(url));
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/update.exe');
      await file.writeAsBytes(response.bodyBytes);
      return file.path;
    } catch (e) {
      return null;
    }
  }

  /// تثبيت التحديث
  static Future<void> installUpdate(String filePath) async {
    await Process.start(filePath, ['/SILENT']);
    exit(0);
  }

  static Future<String> _getCurrentVersion() async {
    // قراءة من ملف أو ثوابت
    return '1.0.0';
  }
}

class UpdateInfo {
  final String version;
  final String downloadUrl;
  final String releaseNotes;

  UpdateInfo({
    required this.version,
    required this.downloadUrl,
    required this.releaseNotes,
  });
}
```

---

## 📋 متطلبات النظام

### للعميل

| المتطلب | المواصفة |
|---------|----------|
| نظام التشغيل | Windows 10/11 (64-bit) |
| المعالج | Intel/AMD 64-bit |
| الذاكرة | 4 GB RAM |
| التخزين | 500 MB |
| الشاشة | 1366x768 أو أعلى |
| الإنترنت | اختياري (للمزامنة فقط) |

### للمطور

| المتطلب | المواصفة |
|---------|----------|
| Flutter SDK | 3.24+ |
| Dart SDK | 3.0+ |
| Visual Studio | 2022 مع C++ workload |
| Git | Latest |

---

## 🚀 خطوات النشر

### 1. إعداد البيئة

```bash
# تثبيت Flutter
https://docs.flutter.dev/get-started/install/windows

# التحقق من التثبيت
flutter doctor
```

### 2. بناء النسخة النهائية

```bash
# استنساخ المشروع
git clone https://github.com/yourusername/flutter-erp.git
cd flutter-erp

# تثبيت التبعيات
flutter pub get

# بناء نسخة الإصدار
flutter build windows --release
```

### 3. إنشاء المثبت

```bash
# تشغيل Inno Setup
"C:\Program Files (x86)\Inno Setup 6\ISCC.exe" setup.iss

# المخرج: installer/ERP-System-Setup.exe
```

### 4. توزيع التطبيق

```bash
# رفع المثبت على موقع التحميل
# أو إرساله للعميل مباشرة
```

---

## 📁 ملفات النشر

```
distribution/
├── ERP-System-Setup.exe      # المثبت
├── ERP-System-Portable.zip   # نسخة محمولة
└── README.txt                # تعليمات التثبيت
```

---

## 📝 دليل المستخدم

### التثبيت

1. قم بتشغيل ملف `ERP-System-Setup.exe`
2. اتبع تعليمات المعالج
3. اختر مجلد التثبيت (افتراضي: `C:\Program Files\ERP System`)
4. انقر "تثبيت"
5. انقر "إنهاء" لإنهاء التثبيت

### التشغيل الأول

1. قم بتشغيل التطبيق من سطح المكتب أو قائمة ابدأ
2. أنشئ حساب المسؤول
3. أضف منتجاتك
4. ابدأ البيع!

---

**الوثيقة:** خطة النشر  
**الإصدار:** 1.0  
**تاريخ التحديث:** 2026-03-08
