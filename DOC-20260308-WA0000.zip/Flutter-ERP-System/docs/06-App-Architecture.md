# 🏗️ بنية التطبيق

## 🎯 مقدمة

يقدم هذا المستند البنية المعمارية لتطبيق Flutter Desktop مع Riverpod للـ State Management.

---

## 🏛️ البنية العامة

```mermaid
flowchart TB
    subgraph Presentation["Presentation Layer"]
        Screens[Screens]
        Widgets[Widgets]
    end
    
    subgraph State["State Layer"]
        Providers[Riverpod Providers]
        Notifiers[StateNotifiers]
    end
    
    subgraph Domain["Domain Layer"]
        Models[Models]
        Repositories[Repositories]
    end
    
    subgraph Data["Data Layer"]
        Database[Drift Database]
        Services[Services]
    end
    
    Presentation --> State
    State --> Domain
    Domain --> Data
```

---

## 📁 هيكل المشروع

```
lib/
├── main.dart                    # نقطة الدخول
├── app.dart                     # MaterialApp
│
├── core/                        # الأساسيات
│   ├── constants/
│   │   ├── app_constants.dart   # الثوابت العامة
│   │   ├── api_constants.dart   # ثوابت API
│   │   └── database_constants.dart
│   ├── theme/
│   │   ├── app_theme.dart       # الثيم الرئيسي
│   │   ├── colors.dart          # الألوان
│   │   └── typography.dart      # الطباعة
│   ├── utils/
│   │   ├── formatters.dart      # تنسيق الأرقام والتواريخ
│   │   ├── validators.dart      # التحقق من البيانات
│   │   └── extensions.dart      # امتدادات Dart
│   └── exceptions/
│       └── app_exceptions.dart  # استثناءات مخصصة
│
├── data/                        # طبقة البيانات
│   ├── database/
│   │   ├── database.dart        # Drift Database
│   │   ├── database.g.dart      # Generated
│   │   ├── tables/              # جداول Drift
│   │   │   ├── products.dart
│   │   │   ├── invoices.dart
│   │   │   ├── customers.dart
│   │   │   ├── inventory.dart
│   │   │   ├── accounting.dart
│   │   │   └── users.dart
│   │   └── daos/                # Data Access Objects
│   │       ├── products_dao.dart
│   │       ├── invoices_dao.dart
│   │       └── ...
│   ├── models/                  # نماذج البيانات
│   │   ├── product_model.dart
│   │   ├── invoice_model.dart
│   │   ├── cart_item_model.dart
│   │   └── ...
│   └── repositories/            # المستودعات
│       ├── product_repository.dart
│       ├── invoice_repository.dart
│       └── ...
│
├── services/                    # الخدمات
│   ├── sync_service.dart        # مزامنة Supabase
│   ├── print_service.dart       # طباعة الفواتير
│   ├── barcode_service.dart     # قارئ الباركود
│   ├── backup_service.dart      # النسخ الاحتياطي
│   └── auth_service.dart        # المصادقة
│
├── providers/                   # Riverpod Providers
│   ├── auth_provider.dart
│   ├── cart_provider.dart
│   ├── pos_provider.dart
│   ├── inventory_provider.dart
│   ├── customers_provider.dart
│   ├── reports_provider.dart
│   └── settings_provider.dart
│
├── screens/                     # الشاشات
│   ├── splash_screen.dart
│   ├── login_screen.dart
│   ├── home_screen.dart
│   │
│   ├── pos/                     # نقطة البيع
│   │   ├── pos_screen.dart
│   │   ├── cart_widget.dart
│   │   ├── product_grid.dart
│   │   ├── payment_dialog.dart
│   │   └── receipt_preview.dart
│   │
│   ├── inventory/               # المخزون
│   │   ├── inventory_screen.dart
│   │   ├── product_form.dart
│   │   ├── product_list.dart
│   │   └── stock_movements.dart
│   │
│   ├── accounting/              # المحاسبة
│   │   ├── accounting_screen.dart
│   │   ├── journal_entries.dart
│   │   └── account_statement.dart
│   │
│   ├── customers/               # العملاء
│   │   ├── customers_screen.dart
│   │   ├── customer_form.dart
│   │   └── customer_details.dart
│   │
│   ├── suppliers/               # الموردين
│   │   ├── suppliers_screen.dart
│   │   └── purchase_form.dart
│   │
│   ├── reports/                 # التقارير
│   │   ├── reports_screen.dart
│   │   ├── sales_report.dart
│   │   ├── inventory_report.dart
│   │   └── chart_widgets.dart
│   │
│   └── settings/                # الإعدادات
│       ├── settings_screen.dart
│       ├── printer_settings.dart
│       └── backup_settings.dart
│
└── widgets/                     # المكونات المشتركة
    ├── common/
    │   ├── app_button.dart
    │   ├── app_text_field.dart
    │   ├── app_card.dart
    │   ├── app_dialog.dart
    │   ├── loading_indicator.dart
    │   └── empty_state.dart
    ├── pos/
    │   ├── product_card.dart
    │   ├── cart_item_tile.dart
    │   └── numeric_keypad.dart
    └── charts/
        ├── sales_chart.dart
        └── pie_chart.dart
```

---

## 🔄 State Management (Riverpod)

### Provider للسلة

```dart
// lib/providers/cart_provider.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/models/cart_item_model.dart';
import '../data/models/product_model.dart';

final cartProvider = StateNotifierProvider<CartNotifier, List<CartItem>>((ref) {
  return CartNotifier();
});

class CartNotifier extends StateNotifier<List<CartItem>> {
  CartNotifier() : super([]);

  void addItem(Product product, {double quantity = 1}) {
    final existingIndex = state.indexWhere(
      (item) => item.product.id == product.id,
    );

    if (existingIndex >= 0) {
      // تحديث الكمية
      final updated = state[existingIndex].copyWith(
        quantity: state[existingIndex].quantity + quantity,
      );
      state = [
        ...state.sublist(0, existingIndex),
        updated,
        ...state.sublist(existingIndex + 1),
      ];
    } else {
      // إضافة جديد
      state = [...state, CartItem(product: product, quantity: quantity)];
    }
  }

  void removeItem(int productId) {
    state = state.where((item) => item.product.id != productId).toList();
  }

  void updateQuantity(int productId, double quantity) {
    if (quantity <= 0) {
      removeItem(productId);
      return;
    }

    state = state.map((item) {
      if (item.product.id == productId) {
        return item.copyWith(quantity: quantity);
      }
      return item;
    }).toList();
  }

  void clear() {
    state = [];
  }

  double get subtotal => state.fold(
    0,
    (sum, item) => sum + (item.product.salePrice * item.quantity),
  );

  double get tax => subtotal * 0.15; // 15% VAT

  double get total => subtotal + tax;

  int get itemCount => state.length;
}
```

### Provider للمخزون

```dart
// lib/providers/inventory_provider.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/repositories/product_repository.dart';
import '../data/models/product_model.dart';

final productRepositoryProvider = Provider<ProductRepository>((ref) {
  return ProductRepository();
});

final productsProvider = FutureProvider<List<Product>>((ref) async {
  final repository = ref.watch(productRepositoryProvider);
  return await repository.getAllProducts();
});

final productsSearchProvider = FutureProvider.family<List<Product>, String>(
  (ref, query) async {
    final repository = ref.watch(productRepositoryProvider);
    return await repository.searchProducts(query);
  },
);

final lowStockProductsProvider = FutureProvider<List<Product>>((ref) async {
  final repository = ref.watch(productRepositoryProvider);
  return await repository.getLowStockProducts();
});
```

---

## 🗄️ Repository Pattern

```dart
// lib/data/repositories/product_repository.dart
import '../database/database.dart';
import '../models/product_model.dart';

class ProductRepository {
  final AppDatabase _db;

  ProductRepository([AppDatabase? db]) : _db = db ?? AppDatabase();

  Future<List<Product>> getAllProducts() async {
    final products = await _db.select(_db.products).get();
    return products.map((p) => Product.fromDrift(p)).toList();
  }

  Future<Product?> getProductById(int id) async {
    final product = await (_db.select(_db.products)
      ..where((p) => p.id.equals(id)))
      .getSingleOrNull();
    return product != null ? Product.fromDrift(product) : null;
  }

  Future<Product?> getProductByBarcode(String barcode) async {
    final product = await (_db.select(_db.products)
      ..where((p) => p.barcode.equals(barcode)))
      .getSingleOrNull();
    return product != null ? Product.fromDrift(product) : null;
  }

  Future<List<Product>> searchProducts(String query) async {
    final products = await (_db.select(_db.products)
      ..where((p) => p.name.contains(query) | p.barcode.contains(query)))
      .get();
    return products.map((p) => Product.fromDrift(p)).toList();
  }

  Future<List<Product>> getLowStockProducts() async {
    final products = await (_db.select(_db.products)
      ..where((p) => p.stockQuantity <= p.minStockLevel))
      .get();
    return products.map((p) => Product.fromDrift(p)).toList();
  }

  Future<int> createProduct(Product product) async {
    return await _db.into(_db.products).insert(
      ProductsCompanion.insert(
        name: product.name,
        barcode: Value(product.barcode),
        salePrice: product.salePrice,
        costPrice: product.costPrice,
        stockQuantity: product.stockQuantity,
        minStockLevel: product.minStockLevel,
      ),
    );
  }

  Future<bool> updateProduct(Product product) async {
    final result = await _db.update(_db.products)
      ..where((p) => p.id.equals(product.id));
    return await result.write(
      ProductsCompanion(
        name: Value(product.name),
        barcode: Value(product.barcode),
        salePrice: Value(product.salePrice),
        costPrice: Value(product.costPrice),
        stockQuantity: Value(product.stockQuantity),
        minStockLevel: Value(product.minStockLevel),
        updatedAt: Value(DateTime.now()),
      ),
    ) > 0;
  }

  Future<int> deleteProduct(int id) async {
    return await (_db.delete(_db.products)
      ..where((p) => p.id.equals(id)))
      .go();
  }
}
```

---

## 🧩 Model Classes

```dart
// lib/data/models/product_model.dart
import '../database/database.dart';

class Product {
  final int? id;
  final String name;
  final String? barcode;
  final String? sku;
  final double salePrice;
  final double costPrice;
  final double stockQuantity;
  final double minStockLevel;
  final bool isActive;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Product({
    this.id,
    required this.name,
    this.barcode,
    this.sku,
    this.salePrice = 0,
    this.costPrice = 0,
    this.stockQuantity = 0,
    this.minStockLevel = 0,
    this.isActive = true,
    this.createdAt,
    this.updatedAt,
  });

  factory Product.fromDrift(ProductData data) {
    return Product(
      id: data.id,
      name: data.name,
      barcode: data.barcode,
      sku: data.sku,
      salePrice: data.salePrice,
      costPrice: data.costPrice,
      stockQuantity: data.stockQuantity,
      minStockLevel: data.minStockLevel,
      isActive: data.isActive,
      createdAt: data.createdAt,
      updatedAt: data.updatedAt,
    );
  }

  double get profit => salePrice - costPrice;

  double get profitMargin => costPrice > 0 ? (profit / costPrice) * 100 : 0;

  bool get isLowStock => stockQuantity <= minStockLevel;

  Product copyWith({
    int? id,
    String? name,
    String? barcode,
    String? sku,
    double? salePrice,
    double? costPrice,
    double? stockQuantity,
    double? minStockLevel,
    bool? isActive,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      barcode: barcode ?? this.barcode,
      sku: sku ?? this.sku,
      salePrice: salePrice ?? this.salePrice,
      costPrice: costPrice ?? this.costPrice,
      stockQuantity: stockQuantity ?? this.stockQuantity,
      minStockLevel: minStockLevel ?? this.minStockLevel,
      isActive: isActive ?? this.isActive,
    );
  }
}
```

---

## 🚀 Navigation

```dart
// lib/core/navigation/app_router.dart
import 'package:go_router/go_router.dart';
import '../../screens/...';

final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: '/login',
      builder: (context, state) => const LoginScreen(),
    ),
    GoRoute(
      path: '/home',
      builder: (context, state) => const HomeScreen(),
    ),
    GoRoute(
      path: '/pos',
      builder: (context, state) => const POSScreen(),
    ),
    GoRoute(
      path: '/inventory',
      builder: (context, state) => const InventoryScreen(),
    ),
    GoRoute(
      path: '/inventory/add',
      builder: (context, state) => const ProductForm(),
    ),
    GoRoute(
      path: '/customers',
      builder: (context, state) => const CustomersScreen(),
    ),
    GoRoute(
      path: '/reports',
      builder: (context, state) => const ReportsScreen(),
    ),
    GoRoute(
      path: '/settings',
      builder: (context, state) => const SettingsScreen(),
    ),
  ],
);
```

---

**الوثيقة:** بنية التطبيق  
**الإصدار:** 1.0  
**تاريخ التحديث:** 2026-03-08
