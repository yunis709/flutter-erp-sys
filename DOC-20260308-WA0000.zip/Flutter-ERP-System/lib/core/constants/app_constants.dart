class AppConstants {
  // App Info
  static const String appName = 'ERP System';
  static const String appVersion = '1.0.0';
  
  // Database
  static const String databaseName = 'erp_database.db';
  
  // Printing
  static const String defaultPrinterIp = '192.168.1.100';
  static const int defaultPrinterPort = 9100;
  
  // Tax
  static const double defaultTaxRate = 0.15; // 15%
  
  // Currency
  static const String currencySymbol = 'ريال';
  static const String currencyCode = 'SAR';
  
  // Pagination
  static const int defaultPageSize = 20;
  
  // Sync
  static const Duration syncInterval = Duration(hours: 24);
}
