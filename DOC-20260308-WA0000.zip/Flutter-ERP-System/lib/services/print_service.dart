import 'package:esc_pos_printer/esc_pos_printer.dart';
import 'package:esc_pos_utils/esc_pos_utils.dart';

class PrintService {
  static const String defaultPrinterIp = '192.168.1.100';
  static const int defaultPrinterPort = 9100;

  static Future<bool> printInvoice({
    required String invoiceNumber,
    required DateTime date,
    required List<Map<String, dynamic>> items,
    required double subtotal,
    required double tax,
    required double total,
    double paidAmount = 0,
    String? customerName,
    String? cashierName,
    String printerIp = defaultPrinterIp,
  }) async {
    try {
      final profile = await CapabilityProfile.load();
      final printer = NetworkPrinter(PaperSize.mm80, profile);

      final result = await printer.connect(printerIp, port: defaultPrinterPort);
      if (result != PosPrintResult.success) {
        return false;
      }

      // Header
      printer.setStyles(const PosStyles(
        align: PosAlign.center,
        bold: true,
        height: PosTextSize.size2,
      ));
      printer.text('سوبر ماركت الأمل');
      printer.setStyles(const PosStyles(align: PosAlign.center, bold: true));
      printer.text('فاتورة ضريبية مبسطة');
      printer.hr();

      // Invoice Info
      printer.setStyles(const PosStyles(align: PosAlign.left));
      printer.text('رقم الفاتورة: $invoiceNumber');
      printer.text('التاريخ: ${_formatDate(date)}');
      if (cashierName != null) printer.text('الكاشير: $cashierName');
      if (customerName != null) printer.text('العميل: $customerName');
      printer.hr();

      // Items Header
      printer.row([
        PosColumn(text: 'المنتج', width: 6, styles: const PosStyles(bold: true)),
        PosColumn(text: 'الكمية', width: 2, styles: const PosStyles(bold: true)),
        PosColumn(text: 'السعر', width: 4, styles: const PosStyles(bold: true, align: PosAlign.right)),
      ]);

      // Items
      for (final item in items) {
        printer.row([
          PosColumn(text: item['name'], width: 6),
          PosColumn(text: '${item['quantity']}', width: 2),
          PosColumn(
            text: '${item['total'].toStringAsFixed(2)}',
            width: 4,
            styles: const PosStyles(align: PosAlign.right),
          ),
        ]);
      }

      printer.hr();

      // Totals
      printer.row([
        PosColumn(text: 'المجموع:', width: 6),
        PosColumn(text: '${subtotal.toStringAsFixed(2)} ريال', width: 6, styles: const PosStyles(align: PosAlign.right)),
      ]);
      printer.row([
        PosColumn(text: 'الضريبة (15%):', width: 6),
        PosColumn(text: '${tax.toStringAsFixed(2)} ريال', width: 6, styles: const PosStyles(align: PosAlign.right)),
      ]);
      printer.setStyles(const PosStyles(bold: true, height: PosTextSize.size2));
      printer.row([
        PosColumn(text: 'الإجمالي:', width: 6),
        PosColumn(text: '${total.toStringAsFixed(2)} ريال', width: 6, styles: const PosStyles(align: PosAlign.right, bold: true)),
      ]);

      if (paidAmount > 0) {
        printer.setStyles(const PosStyles());
        printer.row([
          PosColumn(text: 'المدفوع:', width: 6),
          PosColumn(text: '${paidAmount.toStringAsFixed(2)} ريال', width: 6, styles: const PosStyles(align: PosAlign.right)),
        ]);
        final change = paidAmount - total;
        if (change > 0) {
          printer.row([
            PosColumn(text: 'الباقي:', width: 6),
            PosColumn(text: '${change.toStringAsFixed(2)} ريال', width: 6, styles: const PosStyles(align: PosAlign.right)),
          ]);
        }
      }

      // Footer
      printer.hr();
      printer.setStyles(const PosStyles(align: PosAlign.center));
      printer.text('شكراً لتسوقكم معنا!');
      printer.text('الرقم الضريبي: 300123456700003');
      printer.feed(3);
      printer.cut();
      printer.disconnect();

      return true;
    } catch (e) {
      print('Print error: $e');
      return false;
    }
  }

  static String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  static Future<bool> testConnection(String ip, int port) async {
    try {
      final profile = await CapabilityProfile.load();
      final printer = NetworkPrinter(PaperSize.mm80, profile);
      final result = await printer.connect(ip, port: port);
      if (result == PosPrintResult.success) {
        printer.text('Test successful!');
        printer.feed(2);
        printer.cut();
        printer.disconnect();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }
}
