import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class CustomersScreen extends StatelessWidget {
  const CustomersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('العملاء'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () {
              // TODO: Add customer
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: 10,
        itemBuilder: (context, index) {
          return ListTile(
            leading: CircleAvatar(
              child: Text('ع${index + 1}'),
            ),
            title: Text('عميل ${index + 1}'),
            subtitle: Text('050-123456${index + 1}'),
            trailing: Text('${(index + 1) * 100} ريال'),
            onTap: () {
              // TODO: View customer details
            },
          );
        },
      ),
    );
  }
}
