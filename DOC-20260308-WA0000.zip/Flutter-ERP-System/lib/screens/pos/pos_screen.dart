import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../providers/cart_provider.dart';
import 'cart_widget.dart';
import 'product_grid.dart';

class POSScreen extends ConsumerWidget {
  const POSScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('نقطة البيع'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: () {
              // TODO: Show sales history
            },
          ),
        ],
      ),
      body: Row(
        children: [
          // Products Section
          Expanded(
            flex: 2,
            child: Column(
              children: [
                // Search Bar
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: TextField(
                    autofocus: true,
                    decoration: InputDecoration(
                      hintText: 'امسح الباركود أو اكتب اسم المنتج...',
                      prefixIcon: const Icon(Icons.qr_code_scanner),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.search),
                        onPressed: () {},
                      ),
                    ),
                    onSubmitted: (value) => _searchProduct(context, value),
                  ),
                ),
                // Categories
                Container(
                  height: 50,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _CategoryChip(label: 'الكل', isSelected: true),
                      _CategoryChip(label: 'فواكه'),
                      _CategoryChip(label: 'ألبان'),
                      _CategoryChip(label: 'مخبوزات'),
                      _CategoryChip(label: 'مشروبات'),
                    ],
                  ),
                ),
                // Product Grid
                const Expanded(
                  child: ProductGrid(),
                ),
              ],
            ),
          ),
          // Cart Section
          const CartWidget(),
        ],
      ),
    );
  }

  void _searchProduct(BuildContext context, String query) {
    // TODO: Search and add product to cart
  }
}

class _CategoryChip extends StatelessWidget {
  final String label;
  final bool isSelected;

  const _CategoryChip({
    required this.label,
    this.isSelected = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: FilterChip(
        label: Text(label),
        selected: isSelected,
        onSelected: (value) {},
      ),
    );
  }
}
