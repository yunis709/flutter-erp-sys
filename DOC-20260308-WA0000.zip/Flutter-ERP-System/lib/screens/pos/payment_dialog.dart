import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../providers/cart_provider.dart';
import '../../services/print_service.dart';

class PaymentDialog extends ConsumerStatefulWidget {
  final double total;

  const PaymentDialog({
    super.key,
    required this.total,
  });

  @override
  ConsumerState<PaymentDialog> createState() => _PaymentDialogState();
}

class _PaymentDialogState extends ConsumerState<PaymentDialog> {
  String _paymentMethod = 'cash';
  final _amountController = TextEditingController();
  double _change = 0;

  @override
  void initState() {
    super.initState();
    _amountController.text = widget.total.toStringAsFixed(2);
    _calculateChange();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('إتمام الدفع'),
      content: SizedBox(
        width: 400,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Total
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'المبلغ المستحق:',
                    style: TextStyle(fontSize: 18),
                  ),
                  Text(
                    '${widget.total.toStringAsFixed(2)} ريال',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            // Payment Method
            const Text('طريقة الدفع:', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(
              children: [
                _buildPaymentMethodButton('نقدي', 'cash', Icons.money),
                const SizedBox(width: 8),
                _buildPaymentMethodButton('بطاقة', 'card', Icons.credit_card),
                const SizedBox(width: 8),
                _buildPaymentMethodButton('آجل', 'credit', Icons.account_balance),
              ],
            ),
            const SizedBox(height: 24),
            // Amount
            if (_paymentMethod == 'cash') ...[
              TextField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'المبلغ المدفوع',
                  suffixText: 'ريال',
                ),
                onChanged: (_) => _calculateChange(),
              ),
              const SizedBox(height: 16),
              // Change
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _change >= 0 ? Colors.green.shade50 : Colors.red.shade50,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('الباقي:'),
                    Text(
                      '${_change.toStringAsFixed(2)} ريال',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: _change >= 0 ? Colors.green : Colors.red,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('إلغاء'),
        ),
        ElevatedButton(
          onPressed: _change >= 0 ? _completePayment : null,
          child: const Text('تأكيد'),
        ),
      ],
    );
  }

  Widget _buildPaymentMethodButton(String label, String method, IconData icon) {
    final isSelected = _paymentMethod == method;
    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() {
            _paymentMethod = method;
            if (method != 'cash') {
              _amountController.text = widget.total.toStringAsFixed(2);
            }
            _calculateChange();
          });
        },
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: isSelected ? Theme.of(context).primaryColor : Colors.grey.shade200,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Column(
            children: [
              Icon(icon, color: isSelected ? Colors.white : Colors.grey),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.white : Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _calculateChange() {
    final paid = double.tryParse(_amountController.text) ?? 0;
    setState(() {
      _change = paid - widget.total;
    });
  }

  Future<void> _completePayment() async {
    // TODO: Save invoice to database
    
    // Print receipt
    final cart = ref.read(cartProvider);
    final items = cart.map((item) => {
      'name': item.product.name,
      'quantity': item.quantity,
      'total': item.total,
    }).toList();

    await PrintService.printInvoice(
      invoiceNumber: 'INV-${DateTime.now().millisecondsSinceEpoch}',
      date: DateTime.now(),
      items: items,
      subtotal: ref.read(cartProvider.notifier).subtotal,
      tax: ref.read(cartProvider.notifier).tax,
      total: widget.total,
      paidAmount: double.tryParse(_amountController.text) ?? widget.total,
    );

    // Clear cart
    ref.read(cartProvider.notifier).clear();

    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم إتمام البيع بنجاح!')),
      );
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }
}
