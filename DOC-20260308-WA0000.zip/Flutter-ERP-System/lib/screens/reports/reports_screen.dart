import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('التقارير'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildReportCard(
            context,
            icon: Icons.shopping_cart,
            title: 'مبيعات اليوم',
            subtitle: '1,250 ريال - 15 فاتورة',
            color: Colors.green,
          ),
          _buildReportCard(
            context,
            icon: Icons.trending_up,
            title: 'مبيعات هذا الشهر',
            subtitle: '45,000 ريال - 320 فاتورة',
            color: Colors.blue,
          ),
          _buildReportCard(
            context,
            icon: Icons.inventory,
            title: 'قيمة المخزون',
            subtitle: '125,000 ريال - 1,234 منتج',
            color: Colors.orange,
          ),
          _buildReportCard(
            context,
            icon: Icons.people,
            title: 'أفضل العملاء',
            subtitle: 'عرض قائمة أفضل 10 عملاء',
            color: Colors.purple,
          ),
        ],
      ),
    );
  }

  Widget _buildReportCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.1),
          child: Icon(icon, color: color),
        ),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () {
          // TODO: View report details
        },
      ),
    );
  }
}
