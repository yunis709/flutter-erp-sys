import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الرئيسية'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => context.push('/settings'),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Quick Stats
            Row(
              children: [
                _buildStatCard(
                  context,
                  icon: Icons.shopping_cart,
                  title: 'مبيعات اليوم',
                  value: '1,250 ريال',
                  color: Colors.green,
                ),
                const SizedBox(width: 16),
                _buildStatCard(
                  context,
                  icon: Icons.inventory,
                  title: 'المنتجات',
                  value: '1,234',
                  color: Colors.blue,
                ),
              ],
            ),
            const SizedBox(height: 24),
            // Menu Grid
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                children: [
                  _buildMenuCard(
                    context,
                    icon: Icons.point_of_sale,
                    title: 'نقطة البيع',
                    color: Colors.green,
                    onTap: () => context.push('/pos'),
                  ),
                  _buildMenuCard(
                    context,
                    icon: Icons.inventory_2,
                    title: 'المخزون',
                    color: Colors.blue,
                    onTap: () => context.push('/inventory'),
                  ),
                  _buildMenuCard(
                    context,
                    icon: Icons.people,
                    title: 'العملاء',
                    color: Colors.orange,
                    onTap: () => context.push('/customers'),
                  ),
                  _buildMenuCard(
                    context,
                    icon: Icons.bar_chart,
                    title: 'التقارير',
                    color: Colors.purple,
                    onTap: () => context.push('/reports'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String value,
    required Color color,
  }) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: color, size: 32),
              const SizedBox(height: 8),
              Text(title, style: const TextStyle(color: Colors.grey)),
              const SizedBox(height: 4),
              Text(
                value,
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMenuCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 48, color: color),
            const SizedBox(height: 16),
            Text(
              title,
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ],
        ),
      ),
    );
  }
}
