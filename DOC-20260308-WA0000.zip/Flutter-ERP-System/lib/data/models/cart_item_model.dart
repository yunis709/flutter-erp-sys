import 'package:freezed_annotation/freezed_annotation.dart';
import 'product_model.dart';

part 'cart_item_model.freezed.dart';

@freezed
class CartItem with _$CartItem {
  const factory CartItem({
    required Product product,
    @Default(1) double quantity,
  }) = _CartItem;

  const CartItem._();

  double get total => product.salePrice * quantity;
}
