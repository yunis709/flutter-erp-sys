import 'package:freezed_annotation/freezed_annotation.dart';

part 'product_model.freezed.dart';
part 'product_model.g.dart';

@freezed
class Product with _$Product {
  const factory Product({
    int? id,
    required String name,
    String? barcode,
    String? sku,
    @Default(0) double salePrice,
    @Default(0) double costPrice,
    @Default(0) double stockQuantity,
    @Default(0) double minStockLevel,
    int? categoryId,
    @Default(true) bool isActive,
    @Default(false) bool isSynced,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) = _Product;

  factory Product.fromJson(Map<String, dynamic> json) =>
      _$ProductFromJson(json);
}

extension ProductExtension on Product {
  double get profit => salePrice - costPrice;
  
  double get profitMargin => costPrice > 0 ? (profit / costPrice) * 100 : 0;
  
  bool get isLowStock => stockQuantity <= minStockLevel;
  
  bool get isOutOfStock => stockQuantity <= 0;
}
