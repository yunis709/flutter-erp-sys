import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';

import 'tables/products.dart';
import 'tables/invoices.dart';
import 'tables/customers.dart';

part 'database.g.dart';

@DriftDatabase(tables: [
  Products,
  Categories,
  Invoices,
  InvoiceItems,
  Customers,
  CustomerPayments,
])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  @override
  int get schemaVersion => 1;

  static QueryExecutor _openConnection() {
    return driftDatabase(name: 'erp_database');
  }
}
